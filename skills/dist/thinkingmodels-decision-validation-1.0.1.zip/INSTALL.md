# 决策与验证 / Decisions & validation

Version: 1.0.1 · Slug: `thinkingmodels-decision-validation` · License: CC0-1.0

## Manual installation / 手动安装

This ZIP contains SKILL.md at its root. Extract its contents into ONE of the following new directories, matching your current host. / ZIP 根目录即 SKILL.md，将内容解压至当前宿主下的一个新目录：

- Codex personal: `$CODEX_HOME/skills/thinkingmodels-decision-validation/` (default `~/.codex/skills/thinkingmodels-decision-validation/`)
- Codex project: `<project>/.agents/skills/thinkingmodels-decision-validation/`
- Claude Code personal: `~/.claude/skills/thinkingmodels-decision-validation/`
- Claude Code project: `<project>/.claude/skills/thinkingmodels-decision-validation/`

Inspect SKILL.md first. Do not overwrite an existing directory; ask the user to choose a backup or another scope. Check the final directory contains SKILL.md, agents/, assets/, references/, and LICENSE.txt. Reload skill discovery as required by your host. / 先检查内容；已有同名目录时停止覆盖并询问处理方式；检查安装结构，按宿主要求刷新技能发现。

Invoke by naming `thinkingmodels-decision-validation` or describing the matching task. Try the example in references/worked-example.md. / 用技能名称或对应任务触发，并用示例核对。

## SkillHub installation / 市场安装

Registry ID: `@indiv-klesen/thinkingmodels-decision-validation`. Availability depends on SkillHub review; this ID alone does not prove publication. Use https://skillhub.cn/install/skillhub.md only after the listing is available. Always select the skills directory for your current host. / 上架后才可从市场安装，ID 本身不代表已通过审核；安装目录须匹配当前宿主。

These are instruction packages, not executable installers. No account, network, or MCP is required. Optional public knowledge access is described separately in references/knowledge-access.md. / 本包为指令文件，无自动安装脚本；无需账号、网络或 MCP。
